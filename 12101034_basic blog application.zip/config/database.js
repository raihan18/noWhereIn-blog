/**
 * Created by Raihan on 8/14/2015.
 */
// config/database.js
module.exports = {

    'url' : 'mongodb://localhost/testauth' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};