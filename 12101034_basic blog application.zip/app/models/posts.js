/**
 * Created by Raihan on 8/14/2015.
 */
// app/models/user.js
// load the things we need
var mongoose = require('mongoose');

// define the schema for our user model
var postSchema = mongoose.Schema({
    author  :   String,
    title   :   String,
    body    :   String,
    comments    : [{
        person  : '',
        comment : '',
        posted_at   : new Date()
    }],
    upvotes :   Number,
    posted_at   : new Date()

});

// methods ======================
// create the model for users and expose it to our app
module.exports = mongoose.model('Posts', postSchema);